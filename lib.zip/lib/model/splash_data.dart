List<Map<String, String>> splashData = [
    {"text": "Welcome to SnapBuy", "image": "assets/images/splash_1.png"},
    {
      "text": "Your gateway to effortless shopping.",
      "image": "assets/images/splash_2.png"
    },
    {
      "text": "Snap it. Buy it. Enjoy it.",
      "image": "assets/images/splash_3.png"
    },
  ];