import 'package:flutter/material.dart';
import 'package:project_flutter_shop_ui/constant.dart';
import 'package:project_flutter_shop_ui/size_config.dart';
  ThemeData themeData() {
    return ThemeData(
      fontFamily: 'Muli',
      scaffoldBackgroundColor: Colors.white,
      textTheme: textTheme(),
      visualDensity: VisualDensity.adaptivePlatformDensity,
      inputDecorationTheme: inputDecorationTheme()
    );
  }
  TextTheme textTheme() {
    return const TextTheme(
      titleMedium: TextStyle(color: kTeksColor),
      bodyMedium: TextStyle(color: kTeksColor)
    );
  }
  InputDecorationTheme inputDecorationTheme() {
    const outlineInputBorder = OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                      borderSide: BorderSide(color: kPrimaryColor)
                    );
    var textStyle = TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: getPropotionateScreenWidth(16),
                      color: kPrimaryColor
                    );
    return InputDecorationTheme(
        labelStyle: textStyle,
                    enabledBorder: outlineInputBorder,
                    focusedBorder: outlineInputBorder,
                    border: outlineInputBorder,
                    floatingLabelBehavior: FloatingLabelBehavior.always,
      );
  }

