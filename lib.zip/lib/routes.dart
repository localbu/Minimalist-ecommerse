import 'package:flutter/material.dart';
import 'package:project_flutter_shop_ui/screen/sign_in/sign_in_screen.dart';
import 'package:project_flutter_shop_ui/screen/splash/splash_screen.dart';

final Map<String, WidgetBuilder> routes = {
  SplashScreen.routeName: (context) => const SplashScreen(),
  SignInScreen.routeName: (xontext) => const SignInScreen()
};
